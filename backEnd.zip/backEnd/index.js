const express = require('express');
const app = express();
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');//json web token 
const multer = require('multer');// multer is used to store images that we can upload from the admin panel
const path = require('path');//using path, we can get access to backend in express
const cors = require('cors');

const port = 4000;

app.use(express.json());//with the help of express.json, whatever response we get from request will be automatically parsed as json
app.use(cors());//using this,react app will connect to 4000

//Database connection with mongoDB
mongoose.connect("mongodb://localhost:27017/e-commerce");
//api creation
app.get("/",(req,res)=>{
    res.send("Express app is running");
});
//image storage
const storage = multer.diskStorage({
    destination:'./upload/images',
    filename:(req,file,cb)=>{
        return cb(null,`${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
    }
})
const upload = multer({storage:storage});
app.use('./images',express.static('upload/images'))//static end-pint-using the image folder,we generate image url
//creating upload endpont
app.post('/upload',upload.single('product'),(req,res)=>{
    res.json({
        success:1,
        image_url:`http://localhost:${port}/images/${(req.file.filename)}`
    })
})


//login end point
///all product for all the products

//to add product in a db
// schema for the product creation
const Product = mongoose.model("Product",{
    id:{
        type:Number,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    image:{
        type:String,
        required:true
    },
    category:{
        type:String,
        required:true
    },
    new_price:{
        type:Number,
        required:true
    },
    old_price:{
        type:Number,
        required:true
    },
    date:{
        type:Date,
        default:Date.now,
    },
    available:{
        type:Boolean,
        default:true
    },
})
//use the schema to add to db
app.post('/addProduct',async(req,res)=>{
    const products = await Product.find({});
    let id;
    if(products.length>0){
        let lastProductArray = products.slice(-1);
        let lastproduct = lastProductArray[0];
        id = lastproduct.id + 1;
    }
    else{
        id=1
    }
    const product = new Product({
        id:id,
        name:req.body.name,
        image:req.body.image,
        category:req.body.category,
        new_price:req.body.new_price,
        old_price:req.body.old_price,
    });
    // const product = new Product({
    //     id:req.body.id,
    //     name:req.body.name,
    //     image:req.body.image,
    //     category:req.body.category,
    //     new_price:req.body.new_price,
    //     old_price:req.body.old_price,
    // });
    console.log(product);
    await product.save();
    console.log("saved");
    res.json({
        success:true,
        name:req.body.name,
    })
});

//api for deleting products
app.post('/remove',async(req,res) => {
    await Product.findOneAndDelete({id:req.body.id});
    console.log("Removed from db");
    res.json({
        success:true,
        name:req.body.name
    })
});

// api for all products
app.get('/allProducts', async(req,res)=>{
 var allProducts = await Product.find({});
 console.log("allProducts fetched");
 res.send(allProducts);
});

// schema for login
const customerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    }
});
app.post('/signup', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const customer = new Customer({ name, email, password });
        await customer.save();
        res.status(201).json({ message: 'Customer created successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to create customer' });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const customer = await Customer.findOne({ email, password });
        if (!customer) {
            res.status(401).json({ error: 'Invalid credentials' });
        } else {
            res.status(200).json({ message: 'Login successful' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Failed to login' });
    }
});


module.exports = mongoose.model('Customer', customerSchema);

app.listen(port,(error) =>{
    if (!error) {
        console.log(`Server is running on ${port}`)
    }
    else{
        console.log("DB not connected")
    }

})